package com.yaniv.lec9;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.FileProvider;

import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Objects;

public class FullImageDisplay extends AppCompatActivity {


    ArrayList<File> images;
    TextView tvImageName;
    TextView totalImagesCount;
    ImageView mainImage2;
    Button btnNext;
    Button btnBack;
    Bitmap bitmap;
    String image;
    int counter = 0;
    String currentActionBarColor = "";




    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full_image_display);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        findID();
        //todo: change the actionBar background color (this is default value) ->
        Objects.requireNonNull(getSupportActionBar()).setBackgroundDrawable(new ColorDrawable(Color.parseColor("#aeadad")));
        Bundle extras = getIntent().getExtras();
        images = (ArrayList<File>) extras.get("imagesList");
        if (images != null)
        {
            totalImagesCount.setText(String.valueOf(images.size()));
        }

        image = (String) extras.get("imagePath");
        currentActionBarColor = (String) extras.get("actionBarColor");

        if (!currentActionBarColor.equals(""))
        {
            Objects.requireNonNull(getSupportActionBar()).setBackgroundDrawable(new ColorDrawable(Color.parseColor(currentActionBarColor)));
            btnNext.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(currentActionBarColor)));
            btnNext.setTextColor(Color.parseColor("#FFFFFF"));
            btnBack.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(currentActionBarColor)));
            btnBack.setTextColor(Color.parseColor("#FFFFFF"));
        }

        if (image != null){parseDateTimeFromFile(image);}

        if (images != null)
        {
            bitmap = BitmapFactory.decodeFile(image);
            mainImage2.setImageBitmap(bitmap);
            tvImageName.setVisibility(View.VISIBLE);
        }
    }


    public void findID()
    {
        btnNext = findViewById(R.id.btnNext);
        btnBack = findViewById(R.id.btnBack);
        tvImageName = findViewById(R.id.tvImageName);
        mainImage2 = findViewById(R.id.mainImage2);
        totalImagesCount =findViewById(R.id.totalImagesCount);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu_full_image, menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        showOptions(item);
        return super.onOptionsItemSelected(item);
    }


    // todo: Parser (date/time) from image name in memory.
    public void parseDateTimeFromFile(String val)
    {

        String substring = val.substring(val.indexOf("files/"));
        String substring1 = substring.substring(6);
        String date = substring1.substring(0, substring1.indexOf(',')).replace('_', '/');
        String time = substring1.substring(substring1.indexOf(',')).replace('_', (char) 32);
        String timeFinal = time.substring(1, 9);
        // update the textView with the formatted date/time:
        tvImageName.setText(date + " - " + timeFinal); // adding the image date/time on image
        tvImageName.setBackgroundColor(Color.parseColor("#DCD9D9"));
    }


    //todo: for reading all images files from in-memory when app starts.
    public void readImagesFromAppFolder()
    {
        File[] files = getFilesDir().listFiles();

        if (files != null)
        {
            images = new ArrayList<>();
            images.addAll(Arrays.asList(files));
        }
    }


    //todo: Back/next image view ->
    public void nextBackImage(View view)
    {

        readImagesFromAppFolder();//load all images paths from disk.

        if (view.getId() == R.id.btnNext)
        {
            if (counter < images.size())
            {
                btnBack.setEnabled(true);
                btnBack.getBackground().setAlpha(255);
                File file = images.get(counter++);
                image = file.getAbsolutePath();
                parseDateTimeFromFile(file.getAbsolutePath());
                bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
                mainImage2.setImageBitmap(bitmap);
                tvImageName.setVisibility(View.VISIBLE);
            }
            else
            {
                btnNext.setEnabled(false);
                btnNext.getBackground().setAlpha(150);
                btnBack.setEnabled(true);
                Snackbar.make(btnNext,"No more images...",Snackbar.LENGTH_LONG).show();
            }
        }

        if(view.getId() == R.id.btnBack)
        {
            if (counter > 0)
            {
                btnNext.setEnabled(true);
                btnNext.getBackground().setAlpha(255);
                File file = images.get(--counter);
                image = file.getAbsolutePath();
                parseDateTimeFromFile(file.getAbsolutePath());
                bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
                mainImage2.setImageBitmap(bitmap);
                tvImageName.setVisibility(View.VISIBLE);
            }
            else
            {
                btnBack.setEnabled(false);
                btnBack.getBackground().setAlpha(150);
                btnNext.setEnabled(true);
                Snackbar.make(btnNext,"No more images...",Snackbar.LENGTH_LONG).show();
            }
        }
    }


    //todo: share image ->
    public void shareImage(MenuItem item)
    {
        String[] addresses = {"ybelo@nng.com","yanivb@gpsmore.com"};//
        Uri uri = FileProvider.getUriForFile(this,"com.yaniv.lec9.fileprovider",new File(image));

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_EMAIL,addresses);
        intent.putExtra(Intent.EXTRA_SUBJECT,"Screen shoot");
        intent.putExtra(Intent.EXTRA_STREAM,uri);
        intent.putExtra(Intent.EXTRA_TEXT,"See attached photo:");
        try {
            startActivity(intent);
        }
        catch(Exception e)
        {
            Snackbar.make(btnNext,"No app found to share...",Snackbar.LENGTH_LONG).show();
        }
    }


    //todo: delete image ->
    public void deleteImage(MenuItem item)
    {
        new AlertDialog.Builder(this).setTitle("Delete Image").
                        setMessage("Are you sure you want to delete ?").
                        setNegativeButton("cancel",(dialog, i)->
        {
            Toast.makeText(this, "canceled", Toast.LENGTH_LONG).show();
        }).setPositiveButton("Delete",(dialog,i)->
        {
            for (int j = 0; j < images.size(); j++)
            {
                if (images.get(j).getAbsolutePath().equals(image))
                {
                    File file2Delete = images.get(j);
                    boolean delete = file2Delete.delete();
                    images.remove(j);
                    totalImagesCount.setText(String.valueOf(images.size()));//todo: updating image count
                    Bitmap deletedIcon = BitmapFactory.decodeResource(this.getResources(),R.drawable.deleted);
                    mainImage2.setImageBitmap(deletedIcon);
                    tvImageName.setVisibility(View.INVISIBLE);
                    Toast.makeText(this, "Deleted", Toast.LENGTH_LONG).show();
                    break;
                }
            }

        }).show();
    }


    //todo: Color Change method ->
    public void showOptions(MenuItem item)
    {
        String[] colors = {"#f5b5b5","#628acc","#deaf54"};
        String[] colorsNames = {"Pink","Light Blue","Orange"};
        new AlertDialog.Builder(this).setTitle("Select actionBar color").setItems(colorsNames,(dialog,arrIndex)->
        {
            currentActionBarColor = colors[arrIndex];// todo: for later 'transfer' via intent
            //todo: change the actionBar background color ->
            Objects.requireNonNull(getSupportActionBar()).setBackgroundDrawable
                    (new ColorDrawable(Color.parseColor(colors[arrIndex])));
            Intent intent = new Intent(this,MainActivity.class);
            intent.putExtra("currentActionBarColor",currentActionBarColor);
            startActivity(intent);

        }).show();
    }



}