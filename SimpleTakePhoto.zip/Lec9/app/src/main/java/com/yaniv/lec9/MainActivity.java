package com.yaniv.lec9;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import android.provider.MediaStore;
import android.view.View;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {


    public static final int REQUEST_CODE_TAKE_PHOTO = 1;
    MenuItem item;
    MenuItem actionBarColorChange;
    Button takePhoto;
    Button btnBack;
    Button btnNextGallery;
    Button btnBackGallery;
    Date calendar;
    View verticalGalleryLine;
    View horizontalGalleryLine1;
    View horizontalGalleryLine2;
    private String date;
    private String time;
    private List<ImageView> imageViews;
    private List<TextView> textViews;
    TextView textView1;
    TextView textView2;
    TextView textView3;
    TextView textView4;
    TextView textView5;
    TextView textView6;
    TextView tvNumberOfImages;
    ImageView mainImage;
    ImageView imageView1;
    ImageView imageView2;
    ImageView imageView3;
    ImageView imageView4;
    ImageView imageView5;
    ImageView imageView6;
    ConstraintLayout mainLayout;
    Bitmap bitmap;
    private String timeStamp;
    private int counter = 0;
    private int galleryPage = 0;
    private boolean insideGallery = false;
    private ArrayList<File> imagesList = new ArrayList<>();
    private int imageCounter = 0;
    private String parsedPath = "";
    private String temp = "";
    private String currentActionBarColor = "";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        readImagesFromAppFolder();//todo: reads all images from disk
        findID();
        //todo: change the actionBar background color ->
        Objects.requireNonNull(getSupportActionBar()).setBackgroundDrawable
                (new ColorDrawable(Color.parseColor("#aeadad")));

        galleryLineGrid(true); //todo: hide the gridLines of gallery.
    }


    @Override
    protected void onResume()
    {
        super.onResume();
        readImagesFromAppFolder();

//        if (getIntent().getStringExtra("currentActionBarColor") != null)
//        {
//            String secondActivityActionBarColor = getIntent().getStringExtra("currentActionBarColor");
//            Objects.requireNonNull(getSupportActionBar()).setBackgroundDrawable
//                    (new ColorDrawable(Color.parseColor(secondActivityActionBarColor)));
//            currentActionBarColor = secondActivityActionBarColor;
//        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
            // Inflate the menu; this adds items to the action bar if it is present.
            getMenuInflater().inflate(R.menu.menu_main, menu);

            return true;
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if (id  == R.id.action_show_gallery && imagesList.size() != 0) // validation that we have images in memory.
        {
            showGallery(0);
        }

        else if (id == R.id.action_bar_color_change)
        {
            showOptions(item);
        }
        return super.onOptionsItemSelected(item);
    }


    public void findID()
    {
        takePhoto =  findViewById(R.id.btnTakePhoto);
        mainImage = findViewById(R.id.mainImage);
        mainLayout = findViewById(R.id.MyLayout);
        imageView1 = findViewById(R.id.imageView1);
        imageView2 = findViewById(R.id.imageView2);
        imageView3 = findViewById(R.id.imageView3);
        imageView4 = findViewById(R.id.imageView4);
        imageView5 = findViewById(R.id.imageView5);
        imageView6 = findViewById(R.id.imageView6);
        textView1 = findViewById(R.id.textView1);
        textView2 = findViewById(R.id.textView2);
        textView3 = findViewById(R.id.textView3);
        textView4 = findViewById(R.id.textView4);
        textView5 = findViewById(R.id.textView5);
        textView6 = findViewById(R.id.textView6);
        btnBack = findViewById(R.id.btnBack);
        btnNextGallery = findViewById(R.id.btnNextGallery);
        btnBackGallery = findViewById(R.id.btnBackGallery);
        item = findViewById(R.id.action_show_gallery);
        verticalGalleryLine = findViewById(R.id.verticalGalleryLine);
        horizontalGalleryLine1 = findViewById(R.id.horizontalGalleryLine1);
        horizontalGalleryLine2 = findViewById(R.id.horizontalGalleryLine2);
        actionBarColorChange = findViewById(R.id.action_bar_color_change);
    }



    //todo: Method for taking photo from device camera.
    public void takePhoto(View view)
    {
        //for making sure when switching back to "take picture" page to hide the sub-image view of gallery.
        if (imageViews != null)
        {
            for (ImageView imageView : imageViews)
            {
                imageView.setVisibility(View.INVISIBLE);
            }
        }

        //for making sure when switching back to "take picture" page to hide the TextViews of gallery.
        if (textViews != null)
        {
            for (TextView textView : textViews)
            {
                textView.setVisibility(View.INVISIBLE);
            }
        }

        galleryLineGrid(true);
        mainImage.setVisibility(View.VISIBLE);
        textView1.setVisibility(View.INVISIBLE);

        getTimeStamp(); //todo: gets time/date from device for inserting it as picture name.
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        generateImageName(); // todo: set image name.
        //todo: give permissions to camera app to access the file located in our app folder.
        Uri uri = FileProvider.getUriForFile(this,"com.yaniv.lec9.fileprovider",imagesList.get(imageCounter));
        intent.putExtra(MediaStore.EXTRA_OUTPUT,uri);
        startActivityForResult(intent, REQUEST_CODE_TAKE_PHOTO);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent intent)
    {
        super.onActivityResult(requestCode, resultCode, intent);

        if (requestCode == REQUEST_CODE_TAKE_PHOTO && resultCode == RESULT_OK)
        {
            // getting the path in device memory as String ->
            String absolutePath = imagesList.get(imageCounter).getAbsolutePath();
            // decode the bitmap from image file ->
            Bitmap bitmap = BitmapFactory.decodeFile(absolutePath);
            mainImage.setImageBitmap(bitmap);
//            btnAlbum.setVisibility(View.VISIBLE); //show Gallery Button
            imageCounter++; //
            Snackbar.make(mainImage,timeStamp + " add to memory.",Snackbar.LENGTH_LONG).show();
//            tvNumberOfImages.setText(String.valueOf(imageCounter));
        }
    }



    /**
     *  Method gets 'Date' + 'time' and format the result to be with '_' as divider for later
     *  use this string as a unique image name.
     *  Syntax : 7_17_20_5:38:16_PM
     */
    public void getTimeStamp()
    {
        calendar = Calendar.getInstance().getTime(); // gives time + date from device.
        date = DateFormat.getDateInstance(DateFormat.SHORT).format(calendar);// extract the date
        String finalDate = date.replace('/', '_'); // format the date string chars.
        time = DateFormat.getTimeInstance(DateFormat.DEFAULT).format(calendar);//extract time
        String finalTime = time.replace((char) 32,'_'); // format the time string
        timeStamp = finalDate + "," + finalTime + ".jpg"; // build the date + time + '_' as separator.
    }


    //todo: Method set the image name & path on device memory.
    private void generateImageName()
    {
        // file path ->
        // getFilesDir() will give us the path to our current directory app folder in memory
        File f =  new File(getFilesDir(),  timeStamp);
        imagesList.add(f);
    }


    //_________________________________________ Gallery menu_______________________________________

    //todo: multiple Algorithms for Showing matrix Gallery (with back/next support) ->
    public void showGallery(int loopCounter)
    {
        galleryLineGrid(false);//todo:show gallery gridLines.
        setArrayLists();
        mainImage.setVisibility(View.INVISIBLE); // hide imageView
        btnNextGallery.setVisibility(View.VISIBLE);
        btnBackGallery.setVisibility(View.VISIBLE);
        int i = 0;

        // loops all over the 'File' image list that been read from disk :
        while ( true )
        {
            //todo: avoiding out of bound exception in Arr ->
            if ( loopCounter <  imagesList.size() ) // 0 < 14 == true
           {
               String absolutePath = imagesList.get(loopCounter).getAbsolutePath();
               bitmap = BitmapFactory.decodeFile(absolutePath);

               //todo: making sure only 6 images are shown on gallery each time.
               if (i <= 5)
               {
                   imageViews.get(i).setImageBitmap(bitmap);
                   imageViews.get(i).setVisibility(View.VISIBLE);
                   textViews.get(i).setVisibility(View.VISIBLE);
               }
               else
               {
                   break;
               }

               parseDateTimeFromFile(i,loopCounter);//updating the image name according to state.

               i++;
               loopCounter++;
           }

           else
           {
               for (int j = i; j < 6 ; j++)
               {
                   imageViews.get(j).setVisibility(View.INVISIBLE);
                   textViews.get(j).setVisibility(View.INVISIBLE);
               }

               break;
           }
        }

    }


    /**
     *   This method takes the image path/name from File Object, and parse it + format it to
     *   desired format for injecting it to textView.
     * @param val
     */
    @SuppressLint("SetTextI18n")
    public void parseDateTimeFromFile(int val,int val2)
    {
        String temp = imagesList.get(val2).getAbsolutePath();
        String substring = temp.substring(temp.indexOf("files/"));
        String substring1 = substring.substring(6);
        String date = substring1.substring(0, substring1.indexOf(',')).replace('_', '/');
        String time = substring1.substring(substring1.indexOf(',')).replace('_', (char) 32);
        String timeFinal = time.substring(1, 9);
        // update the textView with the formatted date/time:
        if (val <= 5)
        {
            textViews.get(val).setText(date + " - " + timeFinal); // adding the image date/time on thumbnail
            textViews.get(val).setBackgroundColor(Color.parseColor("#DCD9D9"));
        }

    }


    //todo: Button press (back/next) 6 new Images from im-mem in each press.
    public void nextBackGallery(View view)
    {

        if (view.getId() == R.id.btnNextGallery)
        {
           btnBackGallery.setEnabled(true);
           btnBackGallery.getBackground().setAlpha(255);
           counter = counter + 6;

            if (counter >= imagesList.size())
           {
               btnNextGallery.setEnabled(false);
               btnNextGallery.getBackground().setAlpha(150);

           }
           else
           {
              showGallery(counter);
              if (counter + 6 >= imagesList.size())
              {
                  btnNextGallery.setEnabled(false);
                  btnNextGallery.getBackground().setAlpha(150);
              }
           }
       }

        else if (view.getId() == R.id.btnBackGallery)
        {
            btnNextGallery.setEnabled(true);
            btnNextGallery.getBackground().setAlpha(255);
            counter = counter - 6;

            if (counter < 0)
            {
                 btnBackGallery.setEnabled(false);
                 btnBackGallery.getBackground().setAlpha(150);
                 galleryPage = 0;

            }
            else
            {
                showGallery(counter);
                if (counter - 6 < 0)
                {
                    btnBackGallery.setEnabled(false);
                    btnBackGallery.getBackground().setAlpha(150);
                }
                galleryPage--;
            }

        }
    }


    //todo: Method displays the image selected in full view.
    public void showImage(View view)
    {

        switch (view.getId())
        {
            case R.id.imageView1:
                String tv1 = textView1.getText().toString();
                parsedPath = searchPath(reversPathParse(tv1));
                System.out.println("372:" + parsedPath);
                break;
            case R.id.imageView2:
                String tv2 = textView2.getText().toString();
                parsedPath = searchPath(reversPathParse(tv2));
                System.out.println("377:" + parsedPath);
                break;
            case R.id.imageView3:
                String tv3 = textView3.getText().toString();
                parsedPath = searchPath(reversPathParse(tv3));
                System.out.println("382:" + parsedPath);
                break;
            case R.id.imageView4:
                String tv4 = textView4.getText().toString();
                parsedPath = searchPath(reversPathParse(tv4));
                System.out.println("387:" + parsedPath);
                break;
            case R.id.imageView5:
                String tv5 = textView5.getText().toString();
                parsedPath = searchPath(reversPathParse(tv5));
                System.out.println("392:" + parsedPath);
                break;
            case R.id.imageView6:
                String tv6 = textView6.getText().toString();
                parsedPath = searchPath(reversPathParse(tv6));
                System.out.println("397:" + parsedPath);
                break;
        }

        //todo: opening new Activity when pressing the Thumbnail image.
        Intent intent = new Intent(this,FullImageDisplay.class);
        //todo: sending the all Images list to other activity ('FullImageDisplay').
        intent.putExtra("imagesList", imagesList);
        //todo: sending also the image path from imageView that was pressed.
        intent.putExtra("imagePath", parsedPath);
        intent.putExtra("actionBarColor",currentActionBarColor);
        insideGallery = false;
        startActivity(intent);

    }


    //todo: Algorithm for 'showImage()' method.
    public String searchPath(String parsedName)
    {
        for (File file : imagesList)
        {
            if (file.getAbsolutePath().contains(parsedName.trim()))
            {
                temp  = file.getAbsolutePath();
                break;
            }
        }

        return temp;
    }


    //todo: Algorithm-2 for 'showImage()' method.
    public String reversPathParse(String textView)
    {
        String replace = textView.replace('/', '_');
        String replace2 = replace.replace(" - ", "-");
        return replace2.replace('-', ',');
    }


    //todo: method assigns to Lists (all textVies + all imageVies):
    public void setArrayLists()
    {

        imageViews = new ArrayList<>();
        imageViews.add(imageView1);
        imageViews.add(imageView2);
        imageViews.add(imageView3);
        imageViews.add(imageView4);
        imageViews.add(imageView5);
        imageViews.add(imageView6);

        textViews = new ArrayList<>();
        textViews.add(textView1);
        textViews.add(textView2);
        textViews.add(textView3);
        textViews.add(textView4);
        textViews.add(textView5);
        textViews.add(textView6);
    }

    // todo: show/hide gallery gridLines ->
    public Boolean galleryLineGrid(boolean hideGrid)
    {
       if (hideGrid)
       {
           verticalGalleryLine.setVisibility(View.INVISIBLE);
           horizontalGalleryLine1.setVisibility(View.INVISIBLE);
           horizontalGalleryLine2.setVisibility(View.INVISIBLE);
           return true;
       }

       else
       {
           verticalGalleryLine.setVisibility(View.VISIBLE);
           horizontalGalleryLine1.setVisibility(View.VISIBLE);
           horizontalGalleryLine2.setVisibility(View.VISIBLE);
           return false;
       }
    }


    //_______________________________________ General __________________________________________


    //todo: for reading all images files from in-memory when app starts.
    public void readImagesFromAppFolder()
    {
        File[] files = getFilesDir().listFiles();

        if (files != null)
        {
            imagesList = new ArrayList<>();
            imagesList.addAll(Arrays.asList(files));
            imageCounter = imagesList.size();
        }
    }


    //todo: Color Change method ->
    public void showOptions(MenuItem item)
    {
        String[] colors = {"#aeadad","#f5b5b5","#628acc","#deaf54"};
        String[] colorsNames = {"Gray (Default)","Pink","Light Blue","Orange"};
        new AlertDialog.Builder(this).setTitle("Select actionBar color").setItems(colorsNames,(dialog,arrIndex)->
        {
            currentActionBarColor = colors[arrIndex];// todo: for later 'transfer' via intent
            //todo: change the actionBar background color ->
            Objects.requireNonNull(getSupportActionBar()).setBackgroundDrawable
                    (new ColorDrawable(Color.parseColor(colors[arrIndex])));
            changeThemColor();// see line 545


        }).show();
    }

    // todo: Method changes all elements color on activity ->
    public void changeThemColor()
    {
        if (takePhoto != null)
        {
            takePhoto.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(currentActionBarColor)));
            takePhoto.setTextColor(Color.parseColor("#FFFFFF"));
        }
        if (btnBack != null)
        {
            btnBack.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(currentActionBarColor)));
            btnBack.setTextColor(Color.parseColor("#FFFFFF"));
        }
        if (btnNextGallery != null)
        {
            btnNextGallery.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(currentActionBarColor)));
            btnNextGallery.setTextColor(Color.parseColor("#FFFFFF"));
        }
        if (btnBackGallery != null)
        {
            btnBackGallery.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(currentActionBarColor)));
            btnBackGallery.setTextColor(Color.parseColor("#FFFFFF"));
        }
        if (verticalGalleryLine != null)
        {
            verticalGalleryLine.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(currentActionBarColor)));
        }
        if (horizontalGalleryLine1 != null)
        {
            horizontalGalleryLine1.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(currentActionBarColor)));
        }
        if (horizontalGalleryLine2 != null)
        {
            horizontalGalleryLine2.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(currentActionBarColor)));
        }
        if (mainImage != null)
        {
            System.out.println(currentActionBarColor);
            switch (currentActionBarColor)
            {
        case "#aeadad":
            Bitmap grayCamera = BitmapFactory.decodeResource(this.getResources(),R.drawable.camera);
            mainImage.setImageBitmap(grayCamera);
            break;
        case "#f5b5b5":
            Bitmap pinkCamera = BitmapFactory.decodeResource(this.getResources(),R.drawable.camera_pink);
            mainImage.setImageBitmap(pinkCamera);
            break;
        case "#628acc":
             Bitmap blueCamera = BitmapFactory.decodeResource(this.getResources(),R.drawable.camera_blue);
             mainImage.setImageBitmap(blueCamera);
             break;
        case "#deaf54":
             Bitmap orangeCamera = BitmapFactory.decodeResource(this.getResources(),R.drawable.camera_orange);
             mainImage.setImageBitmap(orangeCamera);
             break;
            }
        }
    }


}